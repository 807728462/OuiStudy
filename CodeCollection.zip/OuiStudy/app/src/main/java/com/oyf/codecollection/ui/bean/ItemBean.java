package com.oyf.codecollection.ui.bean;

public class ItemBean {
    public String name;

    public ItemBean(String name) {
        this.name = name;
    }
}
