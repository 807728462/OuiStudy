package com.oyf.basemodule.mvp;

public class BaseModel implements IModel {
}
