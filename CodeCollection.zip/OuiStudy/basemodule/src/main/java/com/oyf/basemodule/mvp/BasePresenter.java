package com.oyf.basemodule.mvp;

public class BasePresenter implements IPresenter {
}
