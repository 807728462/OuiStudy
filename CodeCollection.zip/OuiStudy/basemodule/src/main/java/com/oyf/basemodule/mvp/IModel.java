package com.oyf.basemodule.mvp;

public interface IModel {
}
